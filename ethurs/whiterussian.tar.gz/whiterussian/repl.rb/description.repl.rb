What is this Japanese?
